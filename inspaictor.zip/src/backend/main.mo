import List "mo:core/List";
import Runtime "mo:core/Runtime";

actor {
  type EarlyAccessRequest = {
    name : Text;
    email : Text;
    company : Text;
    role : Text;
  };

  type InvestorEnquiry = {
    name : Text;
    email : Text;
    company : Text;
    message : Text;
  };

  let earlyAccessRequests = List.empty<EarlyAccessRequest>();
  let investorEnquiries = List.empty<InvestorEnquiry>();

  public shared ({ caller }) func submitEarlyAccessRequest(name : Text, email : Text, company : Text, role : Text) : async () {
    if (name.isEmpty() or email.isEmpty() or company.isEmpty() or role.isEmpty()) {
      Runtime.trap("All fields must be filled.");
    };

    let request : EarlyAccessRequest = {
      name;
      email;
      company;
      role;
    };
    earlyAccessRequests.add(request);
  };

  public shared ({ caller }) func submitInvestorEnquiry(name : Text, email : Text, company : Text, message : Text) : async () {
    if (name.isEmpty() or email.isEmpty() or company.isEmpty() or message.isEmpty()) {
      Runtime.trap("All fields must be filled.");
    };

    let enquiry : InvestorEnquiry = {
      name;
      email;
      company;
      message;
    };
    investorEnquiries.add(enquiry);
  };

  public query ({ caller }) func getAllEarlyAccessRequests() : async [EarlyAccessRequest] {
    earlyAccessRequests.toArray();
  };

  public query ({ caller }) func getAllInvestorEnquiries() : async [InvestorEnquiry] {
    investorEnquiries.toArray();
  };
};
