import type { Principal } from "@icp-sdk/core/principal";
export interface Some<T> {
    __kind__: "Some";
    value: T;
}
export interface None {
    __kind__: "None";
}
export type Option<T> = Some<T> | None;
export interface InvestorEnquiry {
    name: string;
    email: string;
    company: string;
    message: string;
}
export interface EarlyAccessRequest {
    name: string;
    role: string;
    email: string;
    company: string;
}
export interface backendInterface {
    getAllEarlyAccessRequests(): Promise<Array<EarlyAccessRequest>>;
    getAllInvestorEnquiries(): Promise<Array<InvestorEnquiry>>;
    submitEarlyAccessRequest(name: string, email: string, company: string, role: string): Promise<void>;
    submitInvestorEnquiry(name: string, email: string, company: string, message: string): Promise<void>;
}
