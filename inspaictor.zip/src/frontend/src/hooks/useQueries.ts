import { useMutation } from "@tanstack/react-query";
import { useActor } from "./useActor";

export function useSubmitEarlyAccess() {
  const { actor } = useActor();

  return useMutation({
    mutationFn: async ({
      name,
      email,
      company,
      role,
    }: {
      name: string;
      email: string;
      company: string;
      role: string;
    }) => {
      if (!actor) throw new Error("Not connected");
      await actor.submitEarlyAccessRequest(name, email, company, role);
    },
  });
}

export function useSubmitInvestorEnquiry() {
  const { actor } = useActor();

  return useMutation({
    mutationFn: async ({
      name,
      email,
      company,
      message,
    }: {
      name: string;
      email: string;
      company: string;
      message: string;
    }) => {
      if (!actor) throw new Error("Not connected");
      await actor.submitInvestorEnquiry(name, email, company, message);
    },
  });
}
