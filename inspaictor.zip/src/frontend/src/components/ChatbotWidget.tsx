import { MessageCircle, Send, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";

interface Message {
  id: number;
  role: "bot" | "user";
  text: string;
}

const QA_PAIRS: { keywords: string[]; answer: string }[] = [
  {
    keywords: [
      "what is inspaIctor",
      "what is it",
      "what is inspa",
      "inspaIctor",
      "what does",
      "tell me about",
    ],
    answer:
      "InspAIctor is an AI-driven Construction Intelligence System that detects, analyzes, and predicts construction defects across civil, electrical, plumbing, and mechanical systems.",
  },
  {
    keywords: [
      "launch",
      "release",
      "when",
      "available",
      "launch date",
      "coming",
      "ready",
    ],
    answer:
      "We are currently in active development. Selective early access will be introduced soon. Join the waitlist to be notified first.",
  },
  {
    keywords: [
      "who is it for",
      "target",
      "audience",
      "customers",
      "users",
      "who",
      "for whom",
    ],
    answer:
      "InspAIctor is built for developers & builders, infrastructure companies, insurers & regulators, and institutional investors.",
  },
  {
    keywords: [
      "how does it work",
      "how it works",
      "how does",
      "process",
      "mechanism",
      "technology",
    ],
    answer:
      "InspAIctor captures site data, runs it through its AI analysis engine, and delivers Predictive Intelligence Reports to help teams act before failures occur.",
  },
  {
    keywords: ["price", "cost", "pricing", "subscription", "fee"],
    answer:
      "Pricing details will be announced closer to launch. Contact us via the early access form for priority information.",
  },
  {
    keywords: ["contact", "email", "reach", "get in touch"],
    answer:
      "You can reach us through the Request Early Access or Investor Enquiry buttons on our website.",
  },
];

function getAnswer(input: string): string {
  const lower = input.toLowerCase().trim();
  for (const pair of QA_PAIRS) {
    if (pair.keywords.some((kw) => lower.includes(kw.toLowerCase()))) {
      return pair.answer;
    }
  }
  return "Thanks for your question. For detailed inquiries, please use the Contact section or request early access.";
}

let nextId = 1;

export default function ChatbotWidget() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: nextId++,
      role: "bot",
      text: "Hi! I'm the InspAIctor AI Assistant. Ask me anything.",
    },
  ]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open && messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [open]);

  useEffect(() => {
    if (open && inputRef.current) {
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [open]);

  const sendMessage = () => {
    const text = input.trim();
    if (!text) return;

    const userMsg: Message = { id: nextId++, role: "user", text };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setIsTyping(true);

    setTimeout(() => {
      const answer = getAnswer(text);
      const botMsg: Message = { id: nextId++, role: "bot", text: answer };
      setMessages((prev) => [...prev, botMsg]);
      setIsTyping(false);
    }, 700);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <>
      {/* Chat Panel */}
      {open && (
        <div
          className="fixed bottom-24 right-4 sm:right-6 z-50 w-80 sm:w-96 rounded-2xl overflow-hidden animate-slide-in-up"
          style={{
            backgroundColor: "#0D1A2A",
            border: "1px solid rgba(0,194,255,0.3)",
            boxShadow:
              "0 0 40px rgba(0,194,255,0.15), 0 20px 60px rgba(0,0,0,0.5)",
          }}
          data-ocid="chatbot.panel"
        >
          {/* Header */}
          <div
            className="flex items-center justify-between px-4 py-3"
            style={{
              borderBottom: "1px solid rgba(0,194,255,0.2)",
              background:
                "linear-gradient(135deg, rgba(0,194,255,0.1), rgba(103,232,249,0.05))",
            }}
          >
            <div className="flex items-center gap-3">
              <div
                className="w-8 h-8 rounded-full flex items-center justify-center animate-pulse-node"
                style={{
                  backgroundColor: "rgba(0,194,255,0.15)",
                  border: "1px solid #00C2FF",
                }}
              >
                <MessageCircle size={16} style={{ color: "#00C2FF" }} />
              </div>
              <div>
                <p
                  className="text-sm font-semibold"
                  style={{ color: "#ffffff" }}
                >
                  InspAIctor Assistant
                </p>
                <p className="text-xs" style={{ color: "#67E8F9" }}>
                  AI-powered
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setOpen(false)}
              className="p-1.5 rounded-lg transition-colors hover:bg-white/10"
              style={{ color: "#94A3B8" }}
              aria-label="Close chat"
              data-ocid="chatbot.close_button"
            >
              <X size={18} />
            </button>
          </div>

          {/* Messages */}
          <div
            className="h-64 overflow-y-auto p-4 space-y-3"
            style={{ scrollbarWidth: "thin" }}
          >
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
              >
                <div
                  className="max-w-[80%] px-3.5 py-2.5 rounded-2xl text-sm leading-relaxed"
                  style={
                    msg.role === "user"
                      ? {
                          background:
                            "linear-gradient(135deg, #00C2FF, #0098cc)",
                          color: "#0B1420",
                          fontWeight: 500,
                        }
                      : {
                          backgroundColor: "rgba(255,255,255,0.06)",
                          color: "#ffffff",
                          border: "1px solid rgba(255,255,255,0.08)",
                        }
                  }
                >
                  {msg.text}
                </div>
              </div>
            ))}
            {isTyping && (
              <div className="flex justify-start">
                <div
                  className="px-4 py-3 rounded-2xl text-sm"
                  style={{
                    backgroundColor: "rgba(255,255,255,0.06)",
                    border: "1px solid rgba(255,255,255,0.08)",
                  }}
                >
                  <span className="flex gap-1 items-center">
                    {[0, 1, 2].map((i) => (
                      <span
                        key={i}
                        className="w-1.5 h-1.5 rounded-full"
                        style={{
                          backgroundColor: "#00C2FF",
                          animation: `blink-cursor 1.2s ease-in-out ${i * 0.2}s infinite`,
                        }}
                      />
                    ))}
                  </span>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div
            className="px-3 py-3"
            style={{ borderTop: "1px solid rgba(0,194,255,0.15)" }}
          >
            <div className="flex items-center gap-2">
              <input
                ref={inputRef}
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Ask me anything..."
                className="flex-1 bg-transparent text-sm outline-none placeholder-gray-500 py-2 px-1"
                style={{ color: "#ffffff" }}
                aria-label="Message input"
                data-ocid="chatbot.input"
              />
              <button
                type="button"
                onClick={sendMessage}
                disabled={!input.trim()}
                className="p-2.5 rounded-xl transition-all duration-200 disabled:opacity-40 disabled:cursor-not-allowed"
                style={{
                  background: input.trim()
                    ? "linear-gradient(135deg, #00C2FF, #0098cc)"
                    : "rgba(0,194,255,0.1)",
                  color: input.trim() ? "#0B1420" : "#00C2FF",
                  boxShadow: input.trim()
                    ? "0 0 12px rgba(0,194,255,0.3)"
                    : "none",
                }}
                aria-label="Send message"
                data-ocid="chatbot.submit_button"
              >
                <Send size={16} />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Toggle Button */}
      <button
        type="button"
        onClick={() => setOpen((prev) => !prev)}
        className="fixed bottom-6 right-4 sm:right-6 z-50 w-14 h-14 rounded-full flex items-center justify-center transition-all duration-300"
        style={{
          background: "linear-gradient(135deg, #00C2FF, #0098cc)",
          boxShadow: "0 0 24px rgba(0,194,255,0.4), 0 4px 16px rgba(0,0,0,0.3)",
          color: "#0B1420",
        }}
        aria-label={open ? "Close chat" : "Open AI Assistant"}
        aria-expanded={open}
        data-ocid="chatbot.open_modal_button"
      >
        {open ? <X size={22} /> : <MessageCircle size={22} />}
      </button>
    </>
  );
}
