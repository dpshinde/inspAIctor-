import { useEffect, useRef, useState } from "react";

const milestones = [
  {
    id: 1,
    title: "Intelligence Foundation",
    status: "In Progress",
    statusType: "active" as const,
    description:
      "Core AI architecture and multi-discipline defect detection models under active development.",
  },
  {
    id: 2,
    title: "Predictive Systems",
    status: "Under Development",
    statusType: "developing" as const,
    description:
      "Advanced predictive analytics and failure probability engines being engineered.",
  },
  {
    id: 3,
    title: "Industry-Scale Deployment",
    status: "Ahead",
    statusType: "future" as const,
    description:
      "Enterprise-grade infrastructure for real-world construction site deployment.",
  },
  {
    id: 4,
    title: "Early Access",
    status: "Coming Soon",
    statusType: "future" as const,
    description:
      "Selective onboarding for qualified partners, builders, and institutional clients.",
  },
];

const statusColors = {
  active: {
    dot: "#00C2FF",
    text: "#00C2FF",
    badge: "rgba(0,194,255,0.15)",
    glow: true,
  },
  developing: {
    dot: "#67E8F9",
    text: "#67E8F9",
    badge: "rgba(103,232,249,0.1)",
    glow: true,
  },
  future: {
    dot: "#334155",
    text: "#64748B",
    badge: "rgba(100,116,139,0.1)",
    glow: false,
  },
};

export default function TimelineSection() {
  const ref = useRef<HTMLElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 },
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="timeline"
      ref={ref as React.RefObject<HTMLElement>}
      className="relative py-24 sm:py-32 overflow-hidden"
      style={{ backgroundColor: "#0B1420" }}
    >
      {/* Grid overlay */}
      <div
        className="absolute inset-0 grid-overlay pointer-events-none opacity-40"
        aria-hidden="true"
      />

      <div className="relative z-10 max-w-3xl mx-auto px-4 sm:px-6">
        {/* Section label */}
        <p
          className="font-mono text-xs tracking-widest uppercase mb-6 text-center"
          style={{ color: "#00C2FF" }}
        >
          {"// ROADMAP"}
        </p>

        <h2
          className={`text-3xl sm:text-4xl lg:text-5xl font-bold text-center mb-16 transition-all duration-700 ${
            visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
          style={{ color: "#ffffff" }}
        >
          Development Timeline
        </h2>

        {/* Timeline */}
        <div className="relative">
          {/* Vertical line */}
          <div
            className="absolute left-6 sm:left-8 top-0 bottom-0 w-px"
            style={{
              background:
                "linear-gradient(to bottom, #00C2FF, rgba(0,194,255,0.3), rgba(0,194,255,0.1), transparent)",
            }}
            aria-hidden="true"
          />

          <div className="space-y-8">
            {milestones.map((milestone, i) => {
              const colors = statusColors[milestone.statusType];
              return (
                <div
                  key={milestone.id}
                  className={`relative flex gap-8 sm:gap-10 transition-all duration-700 ${
                    visible
                      ? "opacity-100 translate-x-0"
                      : "opacity-0 -translate-x-8"
                  }`}
                  style={{ transitionDelay: `${200 + i * 180}ms` }}
                  data-ocid={`timeline.item.${i + 1}`}
                >
                  {/* Timeline node */}
                  <div className="flex-shrink-0 relative z-10 flex items-start pt-1">
                    <div
                      className={`w-12 h-12 sm:w-16 sm:h-16 rounded-full flex items-center justify-center ${
                        colors.glow ? "animate-pulse-node-slow" : ""
                      }`}
                      style={{
                        backgroundColor: "#0D1A2A",
                        border: `2px solid ${colors.dot}`,
                        boxShadow: colors.glow
                          ? `0 0 16px ${colors.dot}66, 0 0 32px ${colors.dot}22`
                          : "none",
                      }}
                    >
                      <span
                        className="font-mono font-bold text-sm"
                        style={{ color: colors.dot }}
                      >
                        {String(milestone.id).padStart(2, "0")}
                      </span>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="flex-1 glass-card rounded-xl p-5 sm:p-6 mb-2">
                    <div className="flex flex-wrap items-center gap-3 mb-3">
                      <h3
                        className="text-lg font-bold"
                        style={{ color: "#ffffff" }}
                      >
                        {milestone.title}
                      </h3>
                      <span
                        className="px-3 py-0.5 rounded-full text-xs font-mono font-semibold"
                        style={{
                          backgroundColor: colors.badge,
                          color: colors.text,
                          border: `1px solid ${colors.dot}40`,
                        }}
                      >
                        {milestone.status}
                      </span>
                    </div>
                    <p
                      className="text-sm leading-relaxed"
                      style={{ color: "#94A3B8" }}
                    >
                      {milestone.description}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
