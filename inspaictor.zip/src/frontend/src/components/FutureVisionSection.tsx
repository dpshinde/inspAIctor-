import { useEffect, useRef, useState } from "react";

export default function FutureVisionSection() {
  const ref = useRef<HTMLElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.15 },
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="future-vision"
      ref={ref as React.RefObject<HTMLElement>}
      className="relative py-32 sm:py-40 overflow-hidden"
      style={{ backgroundColor: "#0D1A2A" }}
    >
      {/* Deep radial glow */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse 80% 70% at 50% 50%, rgba(0,194,255,0.07) 0%, transparent 65%)",
        }}
        aria-hidden="true"
      />

      {/* Grid overlay */}
      <div
        className="absolute inset-0 grid-overlay pointer-events-none opacity-30"
        aria-hidden="true"
      />

      {/* Technical corner marks */}
      <div
        className="absolute top-8 left-8 w-8 h-8 border-l-2 border-t-2 opacity-30"
        style={{ borderColor: "#00C2FF" }}
        aria-hidden="true"
      />
      <div
        className="absolute top-8 right-8 w-8 h-8 border-r-2 border-t-2 opacity-30"
        style={{ borderColor: "#00C2FF" }}
        aria-hidden="true"
      />
      <div
        className="absolute bottom-8 left-8 w-8 h-8 border-l-2 border-b-2 opacity-30"
        style={{ borderColor: "#00C2FF" }}
        aria-hidden="true"
      />
      <div
        className="absolute bottom-8 right-8 w-8 h-8 border-r-2 border-b-2 opacity-30"
        style={{ borderColor: "#00C2FF" }}
        aria-hidden="true"
      />

      <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 text-center">
        {/* Section label */}
        <p
          className="font-mono text-xs tracking-widest uppercase mb-6"
          style={{ color: "#67E8F9" }}
        >
          {"// VISION"}
        </p>

        <h2
          className={`text-3xl sm:text-5xl lg:text-6xl font-bold mb-8 leading-tight transition-all duration-700 ${
            visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
          style={{
            color: "#ffffff",
            lineHeight: 1.15,
          }}
        >
          The Future of{" "}
          <span
            style={{
              color: "#00C2FF",
              textShadow: "0 0 30px rgba(0,194,255,0.4)",
            }}
          >
            Site Inspection
          </span>
        </h2>

        <p
          className={`text-lg sm:text-xl leading-relaxed mb-10 max-w-2xl mx-auto transition-all duration-700 ${
            visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
          style={{ color: "#94A3B8", transitionDelay: "200ms" }}
        >
          InspAIctor is designed to support intelligent decision-making in
          complex construction environments.
        </p>

        {/* Divider */}
        <div
          className={`h-px max-w-xs mx-auto mb-10 transition-all duration-700 ${
            visible ? "opacity-100 scale-x-100" : "opacity-0 scale-x-0"
          }`}
          style={{
            background:
              "linear-gradient(to right, transparent, #00C2FF, transparent)",
            transitionDelay: "350ms",
            transformOrigin: "center",
          }}
          aria-hidden="true"
        />

        <p
          className={`text-xl sm:text-2xl lg:text-3xl font-bold transition-all duration-700 ${
            visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
          style={{
            color: "#ffffff",
            transitionDelay: "450ms",
            lineHeight: 1.4,
          }}
        >
          The construction industry will{" "}
          <em style={{ color: "#00C2FF", fontStyle: "italic" }}>never</em>{" "}
          operate the same way again.
        </p>
      </div>
    </section>
  );
}
