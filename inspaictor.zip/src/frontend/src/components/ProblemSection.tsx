import {
  AlertTriangle,
  BrainCircuit,
  DollarSign,
  TrendingDown,
} from "lucide-react";
import { useEffect, useRef, useState } from "react";

const problems = [
  {
    icon: AlertTriangle,
    title: "Problems are discovered too late",
    description:
      "Defects surface only after significant damage has occurred, compounding costs and delays.",
  },
  {
    icon: TrendingDown,
    title: "Safety risks increase",
    description:
      "Without predictive visibility, safety hazards remain hidden until incidents occur.",
  },
  {
    icon: DollarSign,
    title: "Repair costs escalate",
    description:
      "Reactive maintenance is exponentially more expensive than early intervention.",
  },
  {
    icon: BrainCircuit,
    title: "Decisions are made without intelligence",
    description:
      "Teams operate on incomplete data, leading to poor risk assessment and costly mistakes.",
  },
];

export default function ProblemSection() {
  const ref = useRef<HTMLElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 },
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="problem"
      ref={ref as React.RefObject<HTMLElement>}
      className="relative py-24 sm:py-32 overflow-hidden"
      style={{ backgroundColor: "#0B1420" }}
    >
      {/* Grid overlay */}
      <div
        className="absolute inset-0 grid-overlay pointer-events-none opacity-40"
        aria-hidden="true"
      />

      {/* Red ambient glow */}
      <div
        className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-64 pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse, rgba(239,68,68,0.05) 0%, transparent 70%)",
        }}
        aria-hidden="true"
      />

      <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6">
        {/* Section label */}
        <p
          className="font-mono text-xs tracking-widest uppercase mb-6 text-center"
          style={{ color: "#EF4444" }}
        >
          {"// THE PROBLEM"}
        </p>

        <h2
          className={`text-3xl sm:text-4xl lg:text-5xl font-bold text-center mb-14 transition-all duration-700 ${
            visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
          style={{ color: "#ffffff" }}
        >
          Construction is still{" "}
          <span
            style={{
              color: "#EF4444",
              textShadow: "0 0 20px rgba(239,68,68,0.3)",
            }}
          >
            reactive.
          </span>
        </h2>

        {/* Problem cards grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-14">
          {problems.map((problem, i) => {
            const Icon = problem.icon;
            return (
              <div
                key={problem.title}
                className={`problem-card-border rounded-r-lg p-6 transition-all duration-700 ${
                  visible
                    ? "opacity-100 translate-y-0"
                    : "opacity-0 translate-y-8"
                }`}
                style={{
                  backgroundColor: "#0D1A2A",
                  transitionDelay: `${200 + i * 120}ms`,
                }}
                data-ocid={`problem.item.${i + 1}`}
              >
                <div className="flex items-start gap-4">
                  <div
                    className="mt-1 p-2 rounded"
                    style={{ backgroundColor: "rgba(239,68,68,0.1)" }}
                  >
                    <Icon size={20} style={{ color: "#EF4444" }} />
                  </div>
                  <div>
                    <h3
                      className="text-base font-semibold mb-2"
                      style={{ color: "#ffffff" }}
                    >
                      {problem.title}
                    </h3>
                    <p
                      className="text-sm leading-relaxed"
                      style={{ color: "#94A3B8" }}
                    >
                      {problem.description}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Closing statement */}
        <div
          className={`text-center transition-all duration-700 ${
            visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
          style={{ transitionDelay: "700ms" }}
        >
          <div
            className="inline-block px-8 py-4 rounded"
            style={{
              border: "1px solid rgba(239,68,68,0.3)",
              backgroundColor: "rgba(239,68,68,0.05)",
            }}
          >
            <p
              className="text-xl sm:text-2xl font-bold italic"
              style={{ color: "#ffffff" }}
            >
              "This should not be normal anymore."
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
