import { Building2, Droplets, Settings, Zap } from "lucide-react";
import { useEffect, useRef, useState } from "react";

const disciplines = [
  {
    icon: Building2,
    title: "Civil",
    description:
      "Structural integrity analysis, foundation monitoring, and load-bearing assessments.",
  },
  {
    icon: Zap,
    title: "Electrical",
    description:
      "Wiring defect detection, circuit anomalies, and compliance verification.",
  },
  {
    icon: Droplets,
    title: "Plumbing",
    description:
      "Leak prediction, pipe integrity monitoring, and pressure analysis.",
  },
  {
    icon: Settings,
    title: "Mechanical",
    description:
      "HVAC system monitoring, mechanical failure prediction, and performance optimization.",
  },
];

export default function SolutionSection() {
  const ref = useRef<HTMLElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 },
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="solution"
      ref={ref as React.RefObject<HTMLElement>}
      className="relative py-24 sm:py-32 overflow-hidden"
      style={{ backgroundColor: "#0D1A2A" }}
    >
      {/* Grid overlay */}
      <div
        className="absolute inset-0 grid-overlay-fine pointer-events-none"
        aria-hidden="true"
      />

      {/* Blue ambient glow */}
      <div
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[400px] pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse, rgba(0,194,255,0.06) 0%, transparent 70%)",
        }}
        aria-hidden="true"
      />

      <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6">
        {/* Section label */}
        <p
          className="font-mono text-xs tracking-widest uppercase mb-6 text-center"
          style={{ color: "#00C2FF" }}
        >
          {"// THE SOLUTION"}
        </p>

        <h2
          className={`text-3xl sm:text-4xl lg:text-5xl font-bold text-center mb-6 transition-all duration-700 ${
            visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
          style={{ color: "#ffffff" }}
        >
          The InspAIctor{" "}
          <span
            style={{
              color: "#00C2FF",
              textShadow: "0 0 20px rgba(0,194,255,0.3)",
            }}
          >
            Intelligence Engine
          </span>
        </h2>

        <p
          className={`text-center text-lg max-w-2xl mx-auto mb-14 transition-all duration-700 ${
            visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
          style={{ color: "#94A3B8", transitionDelay: "150ms" }}
        >
          InspAIctor analyzes site data and identifies hidden risks before they
          become failures.
        </p>

        {/* Discipline cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {disciplines.map((disc, i) => {
            const Icon = disc.icon;
            return (
              <div
                key={disc.title}
                className={`glass-card rounded-xl p-6 text-center group transition-all duration-700 cursor-default ${
                  visible
                    ? "opacity-100 translate-y-0"
                    : "opacity-0 translate-y-8"
                }`}
                style={{
                  transitionDelay: `${250 + i * 120}ms`,
                }}
                data-ocid={`solution.item.${i + 1}`}
              >
                {/* Icon container */}
                <div
                  className="inline-flex items-center justify-center w-14 h-14 rounded-xl mb-4 transition-all duration-300 group-hover:scale-110"
                  style={{
                    backgroundColor: "rgba(0,194,255,0.1)",
                    boxShadow: "0 0 20px rgba(0,194,255,0.1)",
                  }}
                >
                  <Icon size={26} style={{ color: "#00C2FF" }} />
                </div>

                <h3
                  className="text-lg font-bold mb-2"
                  style={{ color: "#ffffff" }}
                >
                  {disc.title}
                </h3>
                <p
                  className="text-sm leading-relaxed"
                  style={{ color: "#94A3B8" }}
                >
                  {disc.description}
                </p>

                {/* Bottom accent line */}
                <div
                  className="mt-4 h-px mx-auto w-0 group-hover:w-full transition-all duration-500"
                  style={{
                    background:
                      "linear-gradient(to right, transparent, #00C2FF, transparent)",
                  }}
                  aria-hidden="true"
                />
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
