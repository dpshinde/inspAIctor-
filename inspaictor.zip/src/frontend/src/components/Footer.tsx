interface FooterProps {
  onRequestAccess: () => void;
  onInvestorEnquiry: () => void;
}

// Social media SVG icons
const LinkedInIcon = () => (
  <svg
    viewBox="0 0 24 24"
    fill="currentColor"
    width="20"
    height="20"
    aria-hidden="true"
  >
    <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
  </svg>
);

const InstagramIcon = () => (
  <svg
    viewBox="0 0 24 24"
    fill="currentColor"
    width="20"
    height="20"
    aria-hidden="true"
  >
    <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
  </svg>
);

const YouTubeIcon = () => (
  <svg
    viewBox="0 0 24 24"
    fill="currentColor"
    width="20"
    height="20"
    aria-hidden="true"
  >
    <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
  </svg>
);

const XIcon = () => (
  <svg
    viewBox="0 0 24 24"
    fill="currentColor"
    width="20"
    height="20"
    aria-hidden="true"
  >
    <path d="M18.901 1.153h3.68l-8.04 9.19L24 22.846h-7.406l-5.8-7.584-6.638 7.584H.474l8.6-9.83L0 1.154h7.594l5.243 6.932ZM17.61 20.644h2.039L6.486 3.24H4.298Z" />
  </svg>
);

const socialLinks = [
  {
    name: "LinkedIn",
    href: "https://linkedin.com/company/inspaIctor",
    Icon: LinkedInIcon,
    ocid: "footer.linkedin.link",
  },
  {
    name: "Instagram",
    href: "https://instagram.com/inspaIctor",
    Icon: InstagramIcon,
    ocid: "footer.instagram.link",
  },
  {
    name: "YouTube",
    href: "https://youtube.com/@inspaIctor",
    Icon: YouTubeIcon,
    ocid: "footer.youtube.link",
  },
  {
    name: "X (Twitter)",
    href: "https://x.com/inspaIctor",
    Icon: XIcon,
    ocid: "footer.twitter.link",
  },
];

export default function Footer({
  onRequestAccess,
  onInvestorEnquiry,
}: FooterProps) {
  const year = new Date().getFullYear();

  return (
    <footer
      id="contact"
      className="relative overflow-hidden"
      style={{ backgroundColor: "#060D18" }}
    >
      {/* Grid overlay */}
      <div
        className="absolute inset-0 grid-overlay pointer-events-none opacity-30"
        aria-hidden="true"
      />

      {/* Top border glow */}
      <div
        className="absolute top-0 left-0 right-0 h-px"
        style={{
          background:
            "linear-gradient(to right, transparent, rgba(0,194,255,0.4), transparent)",
        }}
        aria-hidden="true"
      />

      <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 py-20 text-center">
        {/* Connect section */}
        <p
          className="font-mono text-xs tracking-widest uppercase mb-6"
          style={{ color: "#00C2FF" }}
        >
          {"// CONNECT"}
        </p>

        <h2
          className="text-3xl sm:text-4xl font-bold mb-4"
          style={{ color: "#ffffff" }}
        >
          Connect With Us
        </h2>

        <p
          className="text-base mb-10 max-w-md mx-auto"
          style={{ color: "#94A3B8" }}
        >
          Be part of the construction intelligence revolution. Get early access
          or explore investment opportunities.
        </p>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-14">
          <button
            type="button"
            className="px-8 py-3.5 rounded font-semibold text-base btn-primary min-w-48"
            onClick={onRequestAccess}
            data-ocid="footer.primary_button"
          >
            Request Early Access
          </button>
          <button
            type="button"
            className="px-8 py-3.5 rounded font-semibold text-base btn-outline-blue min-w-48"
            onClick={onInvestorEnquiry}
            data-ocid="footer.secondary_button"
          >
            Investor Enquiry
          </button>
        </div>

        {/* Divider */}
        <div
          className="h-px max-w-xs mx-auto mb-10"
          style={{
            background:
              "linear-gradient(to right, transparent, rgba(0,194,255,0.3), transparent)",
          }}
          aria-hidden="true"
        />

        {/* Social Media */}
        <div className="mb-12">
          <p
            className="text-xs font-mono tracking-widest uppercase mb-5"
            style={{ color: "#94A3B8" }}
          >
            Follow InspAIctor
          </p>
          <div className="flex justify-center gap-5">
            {socialLinks.map(({ name, href, Icon, ocid }) => (
              <a
                key={name}
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-xl flex items-center justify-center transition-all duration-300 hover:scale-110"
                style={{
                  backgroundColor: "rgba(255,255,255,0.06)",
                  color: "#94A3B8",
                  border: "1px solid rgba(255,255,255,0.1)",
                }}
                aria-label={name}
                data-ocid={ocid}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLAnchorElement).style.backgroundColor =
                    "rgba(0,194,255,0.1)";
                  (e.currentTarget as HTMLAnchorElement).style.color =
                    "#67E8F9";
                  (e.currentTarget as HTMLAnchorElement).style.borderColor =
                    "rgba(0,194,255,0.3)";
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLAnchorElement).style.backgroundColor =
                    "rgba(255,255,255,0.06)";
                  (e.currentTarget as HTMLAnchorElement).style.color =
                    "#94A3B8";
                  (e.currentTarget as HTMLAnchorElement).style.borderColor =
                    "rgba(255,255,255,0.1)";
                }}
              >
                <Icon />
              </a>
            ))}
          </div>
        </div>

        {/* Divider */}
        <div
          className="h-px max-w-xs mx-auto mb-10"
          style={{
            background:
              "linear-gradient(to right, transparent, rgba(255,255,255,0.08), transparent)",
          }}
          aria-hidden="true"
        />

        {/* Brand info */}
        <div className="space-y-2">
          <div className="flex items-center justify-center gap-3">
            <img
              src="/assets/uploads/cropped_circle_image-1.png"
              alt="InspAIctor"
              className="h-10 w-10 rounded-full object-cover"
              style={{
                filter:
                  "drop-shadow(0 0 6px rgba(255,255,255,0.6)) drop-shadow(0 0 16px rgba(255,255,255,0.35)) drop-shadow(0 0 30px rgba(200,220,255,0.2))",
              }}
            />
          </div>
          <p className="font-bold text-sm" style={{ color: "#ffffff" }}>
            InspAIctor<sup>®</sup>
          </p>
          <p
            className="text-xs font-mono tracking-wider"
            style={{ color: "#67E8F9" }}
          >
            Construction Intelligence OS
          </p>
          <p className="text-xs" style={{ color: "#94A3B8" }}>
            <a
              href="https://inspaictor.com"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-white transition-colors"
            >
              inspaictor.com
            </a>
          </p>
          <p className="text-xs" style={{ color: "#64748B" }}>
            © {year} InspAIctor. All rights reserved.
          </p>
        </div>

        {/* Caffeine attribution */}
        <div
          className="mt-8 pt-6"
          style={{ borderTop: "1px solid rgba(255,255,255,0.05)" }}
        >
          <p className="text-xs" style={{ color: "#334155" }}>
            © {year}. Built with ♥ using{" "}
            <a
              href={`https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(
                typeof window !== "undefined"
                  ? window.location.hostname
                  : "inspaictor.com",
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-gray-400 transition-colors underline underline-offset-2"
            >
              caffeine.ai
            </a>
          </p>
        </div>
      </div>
    </footer>
  );
}
