import { BarChart3, Cpu, ScanLine } from "lucide-react";
import { useEffect, useRef, useState } from "react";

const steps = [
  {
    number: "01",
    icon: ScanLine,
    title: "Capture Site Data",
    description:
      "Multi-sensor data collection from active construction sites across all systems.",
  },
  {
    number: "02",
    icon: Cpu,
    title: "AI Analysis",
    description:
      "The Intelligence Engine processes data through specialized models for each discipline.",
  },
  {
    number: "03",
    icon: BarChart3,
    title: "Predictive Intelligence Reports",
    description:
      "Actionable reports with risk scores, failure predictions, and recommended interventions.",
  },
];

export default function HowItWorksSection() {
  const ref = useRef<HTMLElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 },
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="how-it-works"
      ref={ref as React.RefObject<HTMLElement>}
      className="relative py-24 sm:py-32 overflow-hidden"
      style={{ backgroundColor: "#0B1420" }}
    >
      {/* Grid overlay */}
      <div
        className="absolute inset-0 grid-overlay pointer-events-none opacity-50"
        aria-hidden="true"
      />

      <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6">
        {/* Section label */}
        <p
          className="font-mono text-xs tracking-widest uppercase mb-6 text-center"
          style={{ color: "#00C2FF" }}
        >
          {"// PROCESS"}
        </p>

        <h2
          className={`text-3xl sm:text-4xl lg:text-5xl font-bold text-center mb-16 transition-all duration-700 ${
            visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
          style={{ color: "#ffffff" }}
        >
          How It Works
        </h2>

        {/* Steps - horizontal on desktop, vertical on mobile */}
        <div className="relative">
          {/* Desktop connecting line */}
          <div
            className="hidden lg:block absolute top-[52px] left-[calc(16.66%-20px)] right-[calc(16.66%-20px)] h-px"
            style={{
              background:
                "linear-gradient(to right, rgba(0,194,255,0.15), rgba(0,194,255,0.5), rgba(0,194,255,0.15))",
            }}
            aria-hidden="true"
          />

          {/* Animated dashes on the line */}
          <div
            className="hidden lg:block absolute top-[51px] left-[calc(16.66%-20px)] right-[calc(16.66%-20px)] h-px overflow-hidden"
            aria-hidden="true"
          >
            <div
              className="h-full"
              style={{
                background:
                  "repeating-linear-gradient(to right, #00C2FF 0px, #00C2FF 8px, transparent 8px, transparent 20px)",
                animation: "moveRight 1.5s linear infinite",
              }}
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 lg:gap-6">
            {steps.map((step, i) => {
              const Icon = step.icon;
              return (
                <div
                  key={step.number}
                  className={`flex flex-col items-center text-center transition-all duration-700 ${
                    visible
                      ? "opacity-100 translate-y-0"
                      : "opacity-0 translate-y-8"
                  }`}
                  style={{ transitionDelay: `${200 + i * 200}ms` }}
                  data-ocid={`how_it_works.item.${i + 1}`}
                >
                  {/* Step node */}
                  <div
                    className="relative w-24 h-24 rounded-full flex items-center justify-center mb-6 animate-pulse-node"
                    style={{
                      backgroundColor: "#0D1A2A",
                      border: "2px solid #00C2FF",
                      boxShadow:
                        "0 0 20px rgba(0,194,255,0.25), inset 0 0 20px rgba(0,194,255,0.05)",
                    }}
                  >
                    {/* Step number */}
                    <span
                      className="absolute -top-3 -right-3 text-xs font-mono font-bold w-7 h-7 rounded-full flex items-center justify-center"
                      style={{ backgroundColor: "#00C2FF", color: "#0B1420" }}
                    >
                      {step.number.replace("0", "")}
                    </span>
                    <Icon size={32} style={{ color: "#00C2FF" }} />
                  </div>

                  {/* Content */}
                  <div className="glass-card rounded-xl p-6 w-full">
                    <h3
                      className="text-lg font-bold mb-3"
                      style={{ color: "#ffffff" }}
                    >
                      {step.title}
                    </h3>
                    <p
                      className="text-sm leading-relaxed"
                      style={{ color: "#94A3B8" }}
                    >
                      {step.description}
                    </p>
                  </div>

                  {/* Mobile vertical connector */}
                  {i < steps.length - 1 && (
                    <div
                      className="lg:hidden w-px h-8 my-2"
                      style={{
                        background:
                          "linear-gradient(to bottom, rgba(0,194,255,0.5), rgba(0,194,255,0.1))",
                      }}
                      aria-hidden="true"
                    />
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <style>{`
        @keyframes moveRight {
          from { transform: translateX(-28px); }
          to { transform: translateX(0px); }
        }
      `}</style>
    </section>
  );
}
