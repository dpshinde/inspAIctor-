import { useRef } from "react";
import ParticleCanvas from "./ParticleCanvas";

interface HeroSectionProps {
  onRequestAccess: () => void;
}

export default function HeroSection({ onRequestAccess }: HeroSectionProps) {
  const learnMoreRef = useRef<HTMLButtonElement>(null);

  const handleLearnMore = () => {
    const el = document.getElementById("what-is-it");
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section
      className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden"
      style={{ backgroundColor: "#0B1420" }}
    >
      {/* Particle Canvas Background */}
      <ParticleCanvas />

      {/* Radial glow overlay */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse 70% 60% at 50% 50%, rgba(0,194,255,0.06) 0%, transparent 70%)",
        }}
        aria-hidden="true"
      />

      {/* Grid overlay */}
      <div
        className="absolute inset-0 grid-overlay pointer-events-none opacity-60"
        aria-hidden="true"
      />

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center text-center px-4 sm:px-6 max-w-4xl mx-auto pt-20">
        {/* Logo */}
        <div className="mb-6 animate-float">
          <img
            src="/assets/uploads/cropped_circle_image-1.png"
            alt="InspAIctor Logo"
            className="h-28 w-28 mx-auto rounded-full object-cover"
            style={{
              filter:
                "drop-shadow(0 0 12px rgba(255,255,255,0.8)) drop-shadow(0 0 30px rgba(255,255,255,0.5)) drop-shadow(0 0 60px rgba(200,220,255,0.35)) drop-shadow(0 0 100px rgba(180,210,255,0.2))",
            }}
          />
        </div>

        {/* Headline */}
        <h1
          className="text-6xl sm:text-7xl lg:text-8xl font-bold tracking-tight mb-3"
          style={{
            color: "#ffffff",
            textShadow: "0 0 40px rgba(0,194,255,0.2)",
            letterSpacing: "-0.02em",
          }}
        >
          InspAIctor
        </h1>

        {/* Subheadline */}
        <p
          className="text-xl sm:text-2xl lg:text-3xl font-semibold mb-4"
          style={{
            color: "#00C2FF",
            textShadow: "0 0 20px rgba(0,194,255,0.3)",
          }}
        >
          Your AI Construction Engineer
        </p>

        {/* Tagline */}
        <p
          className="font-mono text-sm sm:text-base tracking-widest uppercase mb-6"
          style={{ color: "#67E8F9", letterSpacing: "0.25em" }}
        >
          Construction Intelligence OS
        </p>

        {/* Horizontal rule */}
        <div
          className="w-24 h-px mb-6"
          style={{
            background:
              "linear-gradient(to right, transparent, #00C2FF, transparent)",
          }}
          aria-hidden="true"
        />

        {/* Description */}
        <p
          className="text-base sm:text-lg max-w-2xl leading-relaxed mb-10"
          style={{ color: "#94A3B8" }}
        >
          An AI-driven intelligence system designed to detect, analyze and
          predict construction defects across civil, electrical, plumbing and
          mechanical systems.
        </p>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 items-center">
          <button
            type="button"
            className="px-8 py-3.5 rounded font-semibold text-base btn-primary min-w-48"
            onClick={onRequestAccess}
            data-ocid="hero.primary_button"
          >
            Request Early Access
          </button>
          <button
            type="button"
            ref={learnMoreRef}
            className="px-8 py-3.5 rounded font-semibold text-base btn-outline-blue min-w-48"
            onClick={handleLearnMore}
            data-ocid="hero.secondary_button"
          >
            Learn More
          </button>
        </div>

        {/* Scroll indicator */}
        <div className="mt-16 flex flex-col items-center gap-2 opacity-50">
          <span
            className="text-xs font-mono tracking-widest uppercase"
            style={{ color: "#67E8F9" }}
          >
            Scroll to explore
          </span>
          <div
            className="w-px h-8 bg-gradient-to-b from-soft-cyan to-transparent"
            style={{
              backgroundColor: "transparent",
              background: "linear-gradient(to bottom, #67E8F9, transparent)",
            }}
          />
        </div>
      </div>
    </section>
  );
}
