import { Menu, X } from "lucide-react";
import { useEffect, useState } from "react";

const navLinks = [
  { label: "What Is It", href: "#what-is-it" },
  { label: "Problem", href: "#problem" },
  { label: "Solution", href: "#solution" },
  { label: "How It Works", href: "#how-it-works" },
  { label: "Who It's For", href: "#who-its-for" },
  { label: "Timeline", href: "#timeline" },
];

interface NavbarProps {
  onRequestAccess: () => void;
}

export default function Navbar({ onRequestAccess }: NavbarProps) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleNavClick = (href: string) => {
    setMobileOpen(false);
    const el = document.querySelector(href);
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-navy-deep border-b border-electric-blue/20 shadow-glow-blue-sm"
          : "bg-transparent"
      }`}
      style={{ backgroundColor: scrolled ? "#0B1420" : "transparent" }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* Logo — scroll to top */}
          <button
            type="button"
            className="flex items-center gap-3"
            data-ocid="nav.link"
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          >
            <img
              src="/assets/uploads/cropped_circle_image-1.png"
              alt="InspAIctor"
              className="h-10 w-10 rounded-full object-cover"
              style={{
                filter:
                  "drop-shadow(0 0 6px rgba(255,255,255,0.7)) drop-shadow(0 0 14px rgba(255,255,255,0.4)) drop-shadow(0 0 28px rgba(200,220,255,0.2))",
              }}
            />
          </button>

          {/* Desktop Nav */}
          <nav
            className="hidden lg:flex items-center gap-6"
            aria-label="Main navigation"
          >
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="text-sm font-medium transition-colors duration-200 relative group"
                style={{ color: "#94A3B8" }}
                onClick={(e) => {
                  e.preventDefault();
                  handleNavClick(link.href);
                }}
                data-ocid="nav.link"
              >
                {link.label}
                <span
                  className="absolute -bottom-0.5 left-0 right-0 h-px transform scale-x-0 group-hover:scale-x-100 transition-transform duration-200"
                  style={{ backgroundColor: "#00C2FF" }}
                />
              </a>
            ))}
            <button
              type="button"
              className="ml-4 px-5 py-2 rounded text-sm font-semibold btn-primary"
              onClick={onRequestAccess}
              data-ocid="nav.primary_button"
            >
              Request Early Access
            </button>
          </nav>

          {/* Mobile Menu Button */}
          <button
            type="button"
            className="lg:hidden p-2 text-gray-300 hover:text-white transition-colors"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label={mobileOpen ? "Close menu" : "Open menu"}
            aria-expanded={mobileOpen}
            data-ocid="nav.toggle"
          >
            {mobileOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div
          className="lg:hidden border-t border-white/10 animate-slide-in-up"
          style={{ backgroundColor: "#0B1420" }}
        >
          <nav className="flex flex-col px-4 py-4 gap-3">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="py-2 text-sm font-medium border-b border-white/10 last:border-0"
                style={{ color: "#94A3B8" }}
                onClick={(e) => {
                  e.preventDefault();
                  handleNavClick(link.href);
                }}
                data-ocid="nav.link"
              >
                {link.label}
              </a>
            ))}
            <button
              type="button"
              className="mt-2 px-5 py-3 rounded text-sm font-semibold btn-primary w-full"
              onClick={() => {
                setMobileOpen(false);
                onRequestAccess();
              }}
              data-ocid="nav.primary_button"
            >
              Request Early Access
            </button>
          </nav>
        </div>
      )}
    </header>
  );
}
