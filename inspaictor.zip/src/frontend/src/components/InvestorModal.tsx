import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useSubmitInvestorEnquiry } from "@/hooks/useQueries";
import { AlertCircle, CheckCircle2, Loader2 } from "lucide-react";
import { useEffect, useState } from "react";

interface InvestorModalProps {
  open: boolean;
  onClose: () => void;
}

export default function InvestorModal({ open, onClose }: InvestorModalProps) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [company, setCompany] = useState("");
  const [message, setMessage] = useState("");
  const [showSuccess, setShowSuccess] = useState(false);

  const mutation = useSubmitInvestorEnquiry();
  const { reset: resetMutation } = mutation;

  useEffect(() => {
    if (!open) {
      const timer = setTimeout(() => {
        setName("");
        setEmail("");
        setCompany("");
        setMessage("");
        setShowSuccess(false);
        resetMutation();
      }, 300);
      return () => clearTimeout(timer);
    }
  }, [open, resetMutation]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !company || !message) return;

    try {
      await mutation.mutateAsync({ name, email, company, message });
      setShowSuccess(true);
      setTimeout(() => {
        onClose();
      }, 2000);
    } catch {
      // handled via mutation.isError
    }
  };

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent
        className="max-w-md"
        style={{
          backgroundColor: "#0D1A2A",
          border: "1px solid rgba(0,194,255,0.25)",
          color: "#ffffff",
        }}
        data-ocid="investor.modal"
      >
        <DialogHeader>
          <DialogTitle
            className="text-xl font-bold"
            style={{ color: "#ffffff" }}
          >
            Investor Enquiry
          </DialogTitle>
          <p className="text-sm mt-1" style={{ color: "#94A3B8" }}>
            Connect with the InspAIctor team for investment opportunities.
          </p>
        </DialogHeader>

        {/* Success State */}
        {showSuccess && (
          <div
            className="flex flex-col items-center py-8 text-center gap-3"
            data-ocid="investor.success_state"
          >
            <CheckCircle2 size={48} style={{ color: "#00C2FF" }} />
            <p className="text-lg font-semibold" style={{ color: "#ffffff" }}>
              Thank you for your interest!
            </p>
            <p className="text-sm" style={{ color: "#94A3B8" }}>
              Our team will be in touch shortly.
            </p>
          </div>
        )}

        {/* Form */}
        {!showSuccess && (
          <form onSubmit={handleSubmit} className="space-y-4 mt-2">
            {mutation.isPending && (
              <div
                className="flex items-center gap-2 text-sm px-3 py-2 rounded"
                style={{
                  backgroundColor: "rgba(0,194,255,0.1)",
                  color: "#00C2FF",
                }}
                data-ocid="investor.loading_state"
              >
                <Loader2 size={14} className="animate-spin" />
                Sending your enquiry...
              </div>
            )}

            {mutation.isError && (
              <div
                className="flex items-center gap-2 text-sm px-3 py-2 rounded"
                style={{
                  backgroundColor: "rgba(239,68,68,0.1)",
                  color: "#EF4444",
                  border: "1px solid rgba(239,68,68,0.2)",
                }}
                data-ocid="investor.error_state"
              >
                <AlertCircle size={14} />
                Submission failed. Please try again.
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="inv-name" style={{ color: "#94A3B8" }}>
                Full Name
              </Label>
              <Input
                id="inv-name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="John Smith"
                required
                style={{
                  backgroundColor: "rgba(255,255,255,0.05)",
                  borderColor: "rgba(0,194,255,0.2)",
                  color: "#ffffff",
                }}
                data-ocid="investor.name.input"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="inv-email" style={{ color: "#94A3B8" }}>
                Email Address
              </Label>
              <Input
                id="inv-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="john@fund.com"
                required
                style={{
                  backgroundColor: "rgba(255,255,255,0.05)",
                  borderColor: "rgba(0,194,255,0.2)",
                  color: "#ffffff",
                }}
                data-ocid="investor.email.input"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="inv-company" style={{ color: "#94A3B8" }}>
                Company / Fund
              </Label>
              <Input
                id="inv-company"
                value={company}
                onChange={(e) => setCompany(e.target.value)}
                placeholder="Investment Firm LLC"
                required
                style={{
                  backgroundColor: "rgba(255,255,255,0.05)",
                  borderColor: "rgba(0,194,255,0.2)",
                  color: "#ffffff",
                }}
                data-ocid="investor.company.input"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="inv-message" style={{ color: "#94A3B8" }}>
                Message
              </Label>
              <Textarea
                id="inv-message"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Tell us about your investment thesis and interest in InspAIctor..."
                required
                rows={4}
                style={{
                  backgroundColor: "rgba(255,255,255,0.05)",
                  borderColor: "rgba(0,194,255,0.2)",
                  color: "#ffffff",
                  resize: "none",
                }}
                data-ocid="investor.message.textarea"
              />
            </div>

            <div className="flex gap-3 pt-2">
              <Button
                type="submit"
                disabled={
                  mutation.isPending || !name || !email || !company || !message
                }
                className="flex-1"
                style={{
                  background: "linear-gradient(135deg, #00C2FF, #0098cc)",
                  color: "#0B1420",
                  fontWeight: 600,
                }}
                data-ocid="investor.submit_button"
              >
                {mutation.isPending ? (
                  <>
                    <Loader2 size={16} className="mr-2 animate-spin" />
                    Sending...
                  </>
                ) : (
                  "Send Enquiry"
                )}
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                style={{
                  borderColor: "rgba(0,194,255,0.3)",
                  color: "#94A3B8",
                  backgroundColor: "transparent",
                }}
                data-ocid="investor.cancel_button"
              >
                Cancel
              </Button>
            </div>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}
