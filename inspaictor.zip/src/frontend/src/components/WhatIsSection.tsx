import { useEffect, useRef, useState } from "react";

const boldLines = ["It sees.", "It thinks.", "It predicts.", "It decides."];

function useSectionVisible(threshold = 0.3) {
  const ref = useRef<HTMLElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { threshold },
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [threshold]);

  return { ref, visible };
}

export default function WhatIsSection() {
  const { ref, visible } = useSectionVisible(0.2);

  return (
    <section
      id="what-is-it"
      ref={ref as React.RefObject<HTMLElement>}
      className="relative py-24 sm:py-32 overflow-hidden"
      style={{ backgroundColor: "#0D1A2A" }}
    >
      {/* Grid overlay */}
      <div
        className="absolute inset-0 grid-overlay-fine pointer-events-none"
        aria-hidden="true"
      />

      {/* Subtle horizontal lines */}
      <div className="absolute inset-0 pointer-events-none" aria-hidden="true">
        {[16, 32, 48, 64, 80, 96].map((pct) => (
          <div
            key={pct}
            className="absolute left-0 right-0 h-px"
            style={{
              top: `${pct}%`,
              background:
                "linear-gradient(to right, transparent, rgba(0,194,255,0.06), transparent)",
            }}
          />
        ))}
      </div>

      <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 text-center">
        {/* Section label */}
        <p
          className="font-mono text-xs tracking-widest uppercase mb-6"
          style={{ color: "#00C2FF" }}
        >
          {"// ABOUT"}
        </p>

        <h2
          className={`text-3xl sm:text-4xl lg:text-5xl font-bold mb-10 leading-tight transition-all duration-700 ${
            visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
          style={{ color: "#ffffff", lineHeight: 1.2 }}
        >
          Not an App. Not Software.
          <br />
          <span style={{ color: "#00C2FF" }}>An Intelligence System.</span>
        </h2>

        <p
          className={`text-lg sm:text-xl leading-relaxed mb-12 max-w-2xl mx-auto transition-all duration-700 delay-150 ${
            visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
          style={{ color: "#94A3B8", transitionDelay: "150ms" }}
        >
          InspAIctor is being built to transform how construction sites are
          monitored and inspected.
        </p>

        {/* Bold staggered lines */}
        <div className="flex flex-col items-center gap-4">
          {boldLines.map((line, i) => (
            <div
              key={line}
              className={`transition-all duration-600 ${
                visible
                  ? "opacity-100 translate-y-0"
                  : "opacity-0 translate-y-6"
              }`}
              style={{
                transitionDelay: `${300 + i * 180}ms`,
                transitionDuration: "600ms",
              }}
            >
              <p
                className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-wide"
                style={{
                  color: i % 2 === 0 ? "#ffffff" : "#00C2FF",
                  textShadow:
                    i % 2 === 1 ? "0 0 20px rgba(0,194,255,0.3)" : "none",
                }}
              >
                {line}
              </p>
              {i < boldLines.length - 1 && (
                <div
                  className="h-px w-8 mx-auto mt-4"
                  style={{ background: "rgba(0,194,255,0.2)" }}
                  aria-hidden="true"
                />
              )}
            </div>
          ))}
        </div>

        {/* Decorative corner marks — technical drawing style */}
        <div
          className="relative mt-16 mx-auto max-w-lg h-px"
          style={{
            background:
              "linear-gradient(to right, transparent, rgba(0,194,255,0.15), transparent)",
          }}
        />
      </div>
    </section>
  );
}
