import { Building, HardHat, Shield, TrendingUp } from "lucide-react";
import { useEffect, useRef, useState } from "react";

const audiences = [
  {
    icon: HardHat,
    title: "Developers & Builders",
    description:
      "Eliminate costly defects early. Build with confidence and deliver on time.",
  },
  {
    icon: Building,
    title: "Infrastructure Companies",
    description:
      "Monitor large-scale projects with AI-powered intelligence at every stage.",
  },
  {
    icon: Shield,
    title: "Insurers & Regulators",
    description:
      "Access predictive risk data to make informed underwriting and compliance decisions.",
  },
  {
    icon: TrendingUp,
    title: "Institutional Investors",
    description:
      "Get real-time visibility into project health before capital is deployed.",
  },
];

export default function WhoItsForSection() {
  const ref = useRef<HTMLElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 },
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="who-its-for"
      ref={ref as React.RefObject<HTMLElement>}
      className="relative py-24 sm:py-32 overflow-hidden"
      style={{ backgroundColor: "#0D1A2A" }}
    >
      {/* Grid overlay */}
      <div
        className="absolute inset-0 grid-overlay-fine pointer-events-none"
        aria-hidden="true"
      />

      <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6">
        {/* Section label */}
        <p
          className="font-mono text-xs tracking-widest uppercase mb-6 text-center"
          style={{ color: "#00C2FF" }}
        >
          {"// AUDIENCE"}
        </p>

        <h2
          className={`text-3xl sm:text-4xl lg:text-5xl font-bold text-center mb-14 transition-all duration-700 ${
            visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
          style={{ color: "#ffffff" }}
        >
          Built for the{" "}
          <span style={{ color: "#00C2FF" }}>Construction Ecosystem</span>
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {audiences.map((audience, i) => {
            const Icon = audience.icon;
            return (
              <div
                key={audience.title}
                className={`glass-card rounded-xl p-7 group transition-all duration-700 ${
                  visible
                    ? "opacity-100 translate-y-0"
                    : "opacity-0 translate-y-8"
                }`}
                style={{ transitionDelay: `${200 + i * 120}ms` }}
                data-ocid={`who.item.${i + 1}`}
              >
                <div className="flex items-start gap-5">
                  <div
                    className="flex-shrink-0 p-3 rounded-xl transition-all duration-300 group-hover:scale-110"
                    style={{
                      backgroundColor: "rgba(0,194,255,0.1)",
                      boxShadow: "0 0 16px rgba(0,194,255,0.1)",
                    }}
                  >
                    <Icon size={24} style={{ color: "#00C2FF" }} />
                  </div>
                  <div>
                    <h3
                      className="text-lg font-bold mb-2"
                      style={{ color: "#ffffff" }}
                    >
                      {audience.title}
                    </h3>
                    <p
                      className="text-sm leading-relaxed"
                      style={{ color: "#94A3B8" }}
                    >
                      {audience.description}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
