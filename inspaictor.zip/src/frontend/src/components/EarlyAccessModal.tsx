import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useSubmitEarlyAccess } from "@/hooks/useQueries";
import { AlertCircle, CheckCircle2, Loader2 } from "lucide-react";
import { useEffect, useState } from "react";

interface EarlyAccessModalProps {
  open: boolean;
  onClose: () => void;
}

export default function EarlyAccessModal({
  open,
  onClose,
}: EarlyAccessModalProps) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [company, setCompany] = useState("");
  const [role, setRole] = useState("");
  const [showSuccess, setShowSuccess] = useState(false);

  const mutation = useSubmitEarlyAccess();
  const { reset: resetMutation } = mutation;

  // Reset on close
  useEffect(() => {
    if (!open) {
      const timer = setTimeout(() => {
        setName("");
        setEmail("");
        setCompany("");
        setRole("");
        setShowSuccess(false);
        resetMutation();
      }, 300);
      return () => clearTimeout(timer);
    }
  }, [open, resetMutation]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !company || !role) return;

    try {
      await mutation.mutateAsync({ name, email, company, role });
      setShowSuccess(true);
      setTimeout(() => {
        onClose();
      }, 2000);
    } catch {
      // error handled via mutation.isError
    }
  };

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent
        className="max-w-md"
        style={{
          backgroundColor: "#0D1A2A",
          border: "1px solid rgba(0,194,255,0.25)",
          color: "#ffffff",
        }}
        data-ocid="early_access.modal"
      >
        <DialogHeader>
          <DialogTitle
            className="text-xl font-bold"
            style={{ color: "#ffffff" }}
          >
            Request Early Access
          </DialogTitle>
          <p className="text-sm mt-1" style={{ color: "#94A3B8" }}>
            Join the InspAIctor intelligence network. Limited spots available.
          </p>
        </DialogHeader>

        {/* Success State */}
        {showSuccess && (
          <div
            className="flex flex-col items-center py-8 text-center gap-3"
            data-ocid="early_access.success_state"
          >
            <CheckCircle2 size={48} style={{ color: "#00C2FF" }} />
            <p className="text-lg font-semibold" style={{ color: "#ffffff" }}>
              Thank you! You're on the early access list.
            </p>
            <p className="text-sm" style={{ color: "#94A3B8" }}>
              We'll be in touch soon.
            </p>
          </div>
        )}

        {/* Form */}
        {!showSuccess && (
          <form onSubmit={handleSubmit} className="space-y-4 mt-2">
            {/* Loading state indicator */}
            {mutation.isPending && (
              <div
                className="flex items-center gap-2 text-sm px-3 py-2 rounded"
                style={{
                  backgroundColor: "rgba(0,194,255,0.1)",
                  color: "#00C2FF",
                }}
                data-ocid="early_access.loading_state"
              >
                <Loader2 size={14} className="animate-spin" />
                Submitting your request...
              </div>
            )}

            {/* Error state */}
            {mutation.isError && (
              <div
                className="flex items-center gap-2 text-sm px-3 py-2 rounded"
                style={{
                  backgroundColor: "rgba(239,68,68,0.1)",
                  color: "#EF4444",
                  border: "1px solid rgba(239,68,68,0.2)",
                }}
                data-ocid="early_access.error_state"
              >
                <AlertCircle size={14} />
                Submission failed. Please try again.
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="ea-name" style={{ color: "#94A3B8" }}>
                Full Name
              </Label>
              <Input
                id="ea-name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="John Smith"
                required
                style={{
                  backgroundColor: "rgba(255,255,255,0.05)",
                  borderColor: "rgba(0,194,255,0.2)",
                  color: "#ffffff",
                }}
                data-ocid="early_access.name.input"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="ea-email" style={{ color: "#94A3B8" }}>
                Email Address
              </Label>
              <Input
                id="ea-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="john@company.com"
                required
                style={{
                  backgroundColor: "rgba(255,255,255,0.05)",
                  borderColor: "rgba(0,194,255,0.2)",
                  color: "#ffffff",
                }}
                data-ocid="early_access.email.input"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="ea-company" style={{ color: "#94A3B8" }}>
                Company
              </Label>
              <Input
                id="ea-company"
                value={company}
                onChange={(e) => setCompany(e.target.value)}
                placeholder="Your Company"
                required
                style={{
                  backgroundColor: "rgba(255,255,255,0.05)",
                  borderColor: "rgba(0,194,255,0.2)",
                  color: "#ffffff",
                }}
                data-ocid="early_access.company.input"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="ea-role" style={{ color: "#94A3B8" }}>
                Role / Title
              </Label>
              <Input
                id="ea-role"
                value={role}
                onChange={(e) => setRole(e.target.value)}
                placeholder="e.g. Project Manager, CTO"
                required
                style={{
                  backgroundColor: "rgba(255,255,255,0.05)",
                  borderColor: "rgba(0,194,255,0.2)",
                  color: "#ffffff",
                }}
                data-ocid="early_access.role.input"
              />
            </div>

            <div className="flex gap-3 pt-2">
              <Button
                type="submit"
                disabled={
                  mutation.isPending || !name || !email || !company || !role
                }
                className="flex-1 btn-primary"
                style={{
                  background: "linear-gradient(135deg, #00C2FF, #0098cc)",
                  color: "#0B1420",
                  fontWeight: 600,
                }}
                data-ocid="early_access.submit_button"
              >
                {mutation.isPending ? (
                  <>
                    <Loader2 size={16} className="mr-2 animate-spin" />
                    Submitting...
                  </>
                ) : (
                  "Request Access"
                )}
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                style={{
                  borderColor: "rgba(0,194,255,0.3)",
                  color: "#94A3B8",
                  backgroundColor: "transparent",
                }}
                data-ocid="early_access.cancel_button"
              >
                Cancel
              </Button>
            </div>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}
