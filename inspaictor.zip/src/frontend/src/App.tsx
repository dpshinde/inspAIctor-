import { useState } from "react";
import ChatbotWidget from "./components/ChatbotWidget";
import EarlyAccessModal from "./components/EarlyAccessModal";
import Footer from "./components/Footer";
import FutureVisionSection from "./components/FutureVisionSection";
import HeroSection from "./components/HeroSection";
import HowItWorksSection from "./components/HowItWorksSection";
import InvestorModal from "./components/InvestorModal";
import Navbar from "./components/Navbar";
import ProblemSection from "./components/ProblemSection";
import SolutionSection from "./components/SolutionSection";
import TimelineSection from "./components/TimelineSection";
import WhatIsSection from "./components/WhatIsSection";
import WhoItsForSection from "./components/WhoItsForSection";

export default function App() {
  const [earlyAccessOpen, setEarlyAccessOpen] = useState(false);
  const [investorOpen, setInvestorOpen] = useState(false);

  return (
    <div className="min-h-screen" style={{ backgroundColor: "#0B1420" }}>
      {/* Sticky Navbar */}
      <Navbar onRequestAccess={() => setEarlyAccessOpen(true)} />

      {/* Main Content */}
      <main>
        {/* SECTION 1 — Hero */}
        <HeroSection onRequestAccess={() => setEarlyAccessOpen(true)} />

        {/* SECTION 2 — What Is It */}
        <WhatIsSection />

        {/* SECTION 3 — Problem */}
        <ProblemSection />

        {/* SECTION 4 — Solution */}
        <SolutionSection />

        {/* SECTION 5 — How It Works */}
        <HowItWorksSection />

        {/* SECTION 6 — Who It's For */}
        <WhoItsForSection />

        {/* SECTION 7 — Timeline */}
        <TimelineSection />

        {/* SECTION 8 — Future Vision */}
        <FutureVisionSection />
      </main>

      {/* SECTION 10 — Footer */}
      <Footer
        onRequestAccess={() => setEarlyAccessOpen(true)}
        onInvestorEnquiry={() => setInvestorOpen(true)}
      />

      {/* SECTION 9 — Floating AI Chatbot */}
      <ChatbotWidget />

      {/* Modals */}
      <EarlyAccessModal
        open={earlyAccessOpen}
        onClose={() => setEarlyAccessOpen(false)}
      />
      <InvestorModal
        open={investorOpen}
        onClose={() => setInvestorOpen(false)}
      />
    </div>
  );
}
